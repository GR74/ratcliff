# H100 speedup screening results

All comparisons use this run's GPU, software and synthetic observed data.
Final pilot budget: 2048 trials/condition, 40 iterations.
Initial compilation/warm-up is reported separately from timed fitting.

| Model | Variant | Start seed | Fit seconds | Mean active error | Independent G2 | Converged |
|---|---|---:|---:|---:|---:|---|
| A | legacy | 0 | 7.43 | 4.78% | 39.681 | False |
| A | blocked_full | 0 | 8.08 | 4.78% | 40.946 | False |
| A | early_stop | 0 | 8.36 | 4.78% | 40.946 | False |
| A | staged | 0 | 10.16 | 5.22% | 36.080 | False |
| A | combined | 0 | 10.09 | 5.22% | 36.080 | False |
| B | legacy | 0 | 179.98 | 6.02% | 40.832 | False |
| B | blocked_full | 0 | 161.65 | 6.30% | 37.517 | False |
| B | early_stop | 0 | 79.17 | 6.30% | 37.517 | False |
| B | staged | 0 | 262.77 | 7.06% | 31.812 | False |
| B | combined | 0 | 118.78 | 7.06% | 31.812 | False |
| A | blocked_full | 1 | 7.84 | 4.40% | 42.924 | False |
| A | early_stop | 1 | 7.72 | 4.40% | 42.924 | False |
| A | staged | 1 | 11.42 | 4.15% | 42.912 | False |
| A | combined | 1 | 11.33 | 4.15% | 42.912 | False |
| A | legacy | 1 | 8.02 | 4.01% | 42.060 | False |
| B | blocked_full | 1 | 144.87 | 4.11% | 36.665 | False |
| B | early_stop | 1 | 78.33 | 4.11% | 36.665 | False |
| B | staged | 1 | 216.31 | 4.85% | 44.215 | False |
| B | combined | 1 | 102.41 | 4.85% | 44.215 | False |
| B | legacy | 1 | 121.20 | 4.11% | 33.969 | False |
| A | early_stop | 2 | 8.93 | 2.98% | 39.837 | False |
| A | staged | 2 | 11.05 | 3.47% | 40.814 | False |
| A | combined | 2 | 11.02 | 3.47% | 40.814 | False |
| A | legacy | 2 | 7.58 | 1.85% | 37.573 | False |
| A | blocked_full | 2 | 8.53 | 2.98% | 39.837 | False |
| B | early_stop | 2 | 122.82 | 4.23% | 32.101 | False |
| B | staged | 2 | 175.52 | 3.87% | 32.052 | False |
| B | combined | 2 | 89.99 | 3.87% | 32.052 | False |
| B | legacy | 2 | 189.14 | 4.15% | 34.183 | False |

| Comparison | Median fit speedup | Bootstrap 95% interval | Pilot finding |
|---|---:|---|---|
| a:legacy->combined | 0.69x | 0.69-0.74x | not established in this pilot |
| a:blocked_full->early_stop | 0.97x | 0.96-1.02x | not established in this pilot |
| a:blocked_full->staged | 0.73x | 0.69-0.80x | not established in this pilot |
| a:blocked_full->combined | 0.73x | 0.69-0.80x | not established in this pilot |
| b:legacy->combined | 1.76x | 1.18-2.10x | not established in this pilot |
| b:blocked_full->early_stop | 1.95x | 1.85-2.04x | not established in this pilot |
| b:blocked_full->staged | 0.64x | 0.62-0.67x | not established in this pilot |
| b:blocked_full->combined | 1.39x | 1.36-1.41x | not established in this pilot |

The comparison separates legacy code from the paired indexed-noise control.
Distribution intervals and sparse-category limitations are in summary.json.
A screening pass is not proof of equivalence across all datasets or parameters.
Counts, seeds, GPU/driver, package versions, source commit, memory and warm-up
measurements are retained in results.json. Interrupted cases are recorded too.
