# Python profiling diagnostics

- cProfile and line_profiler measure the Python host; they do not time individual XLA/GPU kernels.
- Every workload waits for JAX results. A wait can absorb earlier asynchronous work, so its line is not a kernel location.
- JIT bodies execute as compiled code after tracing; zero line hits there do not mean zero compute cost.
- Unwrapping JIT functions only registers source mappings; this script never invokes their eager versions.
- Compilation/first calls are separate from steady-state passes. New shapes or basis operations during a fit can still compile.
- Instrumented durations include profiler overhead and are not speedup evidence; use benchmark_speedups.py for comparisons.
- Basis cold means an empty Python K-L basis cache, not an empty XLA or operating-system cache.
- Cumulative function times overlap and must not be added together.
- Fits use synthetic data, fixed seeds and a small iteration budget; these are bottleneck diagnostics, not convergence/recovery tests.

## B / legacy

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 7.8611 | 7.9000 | 7.9043 |
| objective | 2 | 7.9656 | 8.0168 | 8.2186 |
| basis_cold | 1 | 0.8959 | 0.8630 | 0.8709 |
| basis_cache_hit | 2 | 0.0030 | 0.0012 | 0.0019 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2479 (block_until_ready) | 3.9253 | 3.9253 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 3.9051 | 3.9053 | 8 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0193 | 0.0203 | 128 |
| model_b/simulate.py:273 (simulate_b) | 0.0089 | 0.0090 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0023 | 0.0338 | 132 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/objective.py:49 | 0.0077 | 2 | `jnp.array([ter, st, cr, crsd, sis, sig, sv]),` |
| model_b/simulate.py:302 | 0.0061 | 8 | `return _simulate_b_kl_inner(` |
| model_b/objective.py:40 | 0.0033 | 2 | `ter = jnp.maximum(params[0], 175.0)` |
| model_b/objective.py:43 | 0.0025 | 2 | `crsd = jnp.clip(params[3], 0.01, cr / 2.0)` |
| model_b/objective.py:41 | 0.0023 | 2 | `st = jnp.clip(params[1], 10.0, ter * 1.5)` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 7.5977 | 7.6006 | 1046 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0674 | 0.0761 | 916 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0186 | 7.8586 | 1828 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0182 | 7.8987 | 3794 |
| .venv/lib/python3.12/site-packages/jax/_src/util.py:270 (wrapper) | 0.0153 | 0.0252 | 9470 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/objective.py:153 | 8.1761 | 2 | `g2_per_cond = g2_vmap(rts, cats, data["prop"], data["count"], data["quant"])` |
| model_b/objective.py:88 | 8.1729 | 2 | `return jnp.array([per_cat(i) for i in range(MC)]).sum()` |
| model_b/objective.py:106 | 0.0147 | 2 | `p = clamp_b(params)` |
| model_b/objective.py:144 | 0.0075 | 4 | `rts, cats = sim_vmap(` |
| model_b/objective.py:112 | 0.0065 | 6 | `jnp.array([p[d1], p[d2], p[d3]]) for (d1, d2, d3) in COND_MAP_B` |

### basis_cold: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/grf_kl.py:77 (_calc_kl_basis_impl) | 0.7291 | 0.8557 | 1 |
| ~:0 (<method 'astype' of 'numpy.ndarray' objects>) | 0.0652 | 0.0652 | 12 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0518 | 0.0520 | 46 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0029 | 0.0029 | 1 |
| model_b/grf_kl.py:26 (_cached_calc_kl_basis) | 0.0017 | 0.8574 | 1 |

Identical workload summaries across the three passes: True.

### basis_cold: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.8657 | 2 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:31 | 0.8657 | 1 | `result = _calc_kl_basis_impl(sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:121 | 0.2978 | 1 | `re = (np.cos(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:122 | 0.2886 | 1 | `im = (np.sin(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:128 | 0.0873 | 1 | `V[:, 0 : 2 * K : 2] = re.T        # even columns = real parts` |

### basis_cache_hit: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0004 | 0.0004 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0003 | 0.0004 | 4 |
| scripts/profile_speedups.py:188 (build_basis) | 0.0000 | 0.0012 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/indexing.py:359 (to_static_slice) | 0.0000 | 0.0001 | 2 |
| ~:0 (<method 'disable' of '_lsprof.Profiler' objects>) | 0.0000 | 0.0000 | 1 |

Identical workload summaries across the three passes: True.

### basis_cache_hit: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.0000 | 4 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:72 | 0.0000 | 2 | `sig_key = round(float(sig), 6)` |
| model_b/grf_kl.py:28 | 0.0000 | 2 | `cached = _basis_cache.get(cache_key)` |
| model_b/grf_kl.py:27 | 0.0000 | 2 | `cache_key = (sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:30 | 0.0000 | 2 | `return cached` |

## B / combined

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 0.7272 | 0.7379 | 0.7542 |
| objective | 2 | 1.0285 | 1.2497 | 1.4033 |
| basis_cold | 1 | 0.8761 | 0.8722 | 0.9120 |
| basis_cache_hit | 2 | 0.0027 | 0.0013 | 0.0020 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/simulate.py:351 (simulate_b_blocked_with_work) | 0.6837 | 0.7119 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0142 | 0.0148 | 232 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0076 | 0.0082 | 118 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/array_methods.py:795 (_operator_truediv) | 0.0025 | 0.0026 | 50 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0023 | 0.0024 | 8 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/simulate.py:382 | 0.7198 | 8 | `rt, cat, _work = simulate_b_blocked_with_work(` |
| model_b/simulate.py:372 | 0.6848 | 8 | `return _simulate_b_blocked_core(` |
| model_b/simulate.py:373 | 0.0203 | 4 | `key, ter, st, cr, crsd, drift.reshape(-1), zone_array(si).reshape(-1),` |
| model_b/simulate.py:362 | 0.0098 | 4 | `v1, v2, v3 = drift_bumps(sis=sis)` |
| model_b/simulate.py:50 | 0.0083 | 4 | `return bump(UJ1), bump(UJ2), bump(UJ3)` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/simulate.py:351 (simulate_b_blocked_with_work) | 0.6905 | 0.7176 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0980 | 0.1016 | 1174 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0698 | 0.0788 | 914 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0216 | 0.3628 | 1826 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0192 | 0.4157 | 3918 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/objective.py:131 | 0.7193 | 10 | `outputs = [sim_b.simulate_b_blocked(` |
| model_b/simulate.py:382 | 0.7191 | 8 | `rt, cat, _work = simulate_b_blocked_with_work(` |
| model_b/simulate.py:372 | 0.6858 | 8 | `return _simulate_b_blocked_core(` |
| model_b/objective.py:153 | 0.6446 | 2 | `g2_per_cond = g2_vmap(rts, cats, data["prop"], data["count"], data["quant"])` |
| model_b/objective.py:88 | 0.6399 | 2 | `return jnp.array([per_cat(i) for i in range(MC)]).sum()` |

### basis_cold: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/grf_kl.py:77 (_calc_kl_basis_impl) | 0.7395 | 0.8648 | 1 |
| ~:0 (<method 'astype' of 'numpy.ndarray' objects>) | 0.0657 | 0.0657 | 12 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0492 | 0.0494 | 46 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0030 | 0.0030 | 1 |
| model_b/grf_kl.py:26 (_cached_calc_kl_basis) | 0.0017 | 0.8665 | 1 |

Identical workload summaries across the three passes: True.

### basis_cold: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.9076 | 2 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:31 | 0.9075 | 1 | `result = _calc_kl_basis_impl(sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:121 | 0.3132 | 1 | `re = (np.cos(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:122 | 0.3065 | 1 | `im = (np.sin(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:128 | 0.0939 | 1 | `V[:, 0 : 2 * K : 2] = re.T        # even columns = real parts` |

### basis_cache_hit: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0004 | 0.0004 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0004 | 0.0004 | 2 |
| scripts/profile_speedups.py:188 (build_basis) | 0.0000 | 0.0013 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/indexing.py:359 (to_static_slice) | 0.0000 | 0.0001 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0000 | 0.0005 | 4 |

Identical workload summaries across the three passes: True.

### basis_cache_hit: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.0000 | 4 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:72 | 0.0000 | 2 | `sig_key = round(float(sig), 6)` |
| model_b/grf_kl.py:28 | 0.0000 | 2 | `cached = _basis_cache.get(cache_key)` |
| model_b/grf_kl.py:27 | 0.0000 | 2 | `cache_key = (sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:30 | 0.0000 | 2 | `return cached` |

## A / legacy

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 0.1167 | 0.1392 | 0.1327 |
| objective | 2 | 0.3282 | 0.4243 | 0.4823 |
| basis_factor | 2 | 0.0042 | 0.0040 | 0.0050 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2479 (block_until_ready) | 0.0460 | 0.0460 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0414 | 0.0424 | 186 |
| scripts/profile_speedups.py:205 (simulate_arrays) | 0.0048 | 0.1377 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0025 | 0.0583 | 194 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0025 | 0.0029 | 16 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| scripts/profile_speedups.py:136 | 0.1327 | 1 | `row["line_profiler_seconds"], row["line_profiler_result"] = timed(batch)` |
| scripts/profile_speedups.py:51 | 0.1327 | 1 | `value = call()` |
| scripts/profile_speedups.py:227 | 0.1317 | 2 | `rt, cat = self.simulate_arrays()` |
| scripts/profile_speedups.py:214 | 0.0480 | 8 | `values = (key, p[0], p[1], p[bi], p[3], p[4], p[5], p[di], nsim, self.chunk)` |
| scripts/profile_speedups.py:223 | 0.0464 | 2 | `self.jax.block_until_ready((rt, cat))` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.1418 | 0.1437 | 676 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0450 | 0.0536 | 552 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0118 | 0.3110 | 1100 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0116 | 0.3418 | 2336 |
| .venv/lib/python3.12/site-packages/jax/_src/util.py:270 (wrapper) | 0.0103 | 0.0172 | 5870 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/objective.py:121 | 0.4439 | 4 | `g2_per_cond = g2_vmap(` |
| model_a/objective.py:70 | 0.4401 | 2 | `contribs = jnp.array([per_cat(i) for i in range(MC)])` |
| model_a/objective.py:87 | 0.0143 | 2 | `p = clamp(params)` |
| model_a/objective.py:94 | 0.0071 | 2 | `cond_keys = jnp.stack([prng.split_for_condition(key, ci) for ci in range(4)])` |
| model_a/objective.py:111 | 0.0063 | 4 | `rts, cats = sim_vmap(` |

### basis_factor: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0009 | 0.0010 | 16 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0008 | 0.0009 | 14 |
| model_a/simulate.py:31 (chol_factor) | 0.0003 | 0.0029 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0002 | 0.0002 | 2 |
| ~:0 (<built-in method builtins.isinstance>) | 0.0001 | 0.0001 | 352 |

Identical workload summaries across the three passes: True.

### basis_factor: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/simulate.py:34 | 0.0025 | 2 | `K = jnp.exp(-0.5 * d * d / (sig * sig)) + 1e-12 * jnp.eye(N)` |
| model_a/simulate.py:33 | 0.0010 | 2 | `d = IDX[:, None] - IDX[None, :]` |
| model_a/simulate.py:35 | 0.0002 | 2 | `return jnp.linalg.cholesky(K)` |

## A / combined

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 0.1254 | 0.1335 | 0.1394 |
| objective | 2 | 0.3103 | 0.4133 | 0.5154 |
| basis_factor | 2 | 0.0049 | 0.0041 | 0.0057 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_a/simulate.py:165 (simulate_blocked) | 0.0985 | 0.0985 | 8 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0142 | 0.0146 | 186 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0016 | 0.0017 | 16 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0015 | 0.0015 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0010 | 0.0209 | 194 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/simulate.py:169 | 0.0975 | 16 | `rt, cat, _work = simulate_blocked_with_work(` |
| model_a/simulate.py:173 | 0.0000 | 8 | `return rt, cat` |
| model_a/simulate.py:170 | 0.0000 | 8 | `key, ter, st, cr, crsd, si, sig, av, nsim, chunk_size,` |
| model_a/simulate.py:171 | 0.0000 | 8 | `time_block_size, stop_early, compact,` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_a/simulate.py:165 (simulate_blocked) | 0.0983 | 0.0983 | 8 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0639 | 0.0660 | 728 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0410 | 0.0458 | 550 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0106 | 0.2410 | 2384 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0106 | 0.2057 | 1098 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/objective.py:121 | 0.3721 | 4 | `g2_per_cond = g2_vmap(` |
| model_a/objective.py:70 | 0.3673 | 2 | `contribs = jnp.array([per_cat(i) for i in range(MC)])` |
| model_a/objective.py:100 | 0.1000 | 18 | `outputs = [sim_new.simulate_blocked(` |
| model_a/simulate.py:169 | 0.0997 | 16 | `rt, cat, _work = simulate_blocked_with_work(` |
| model_a/objective.py:87 | 0.0134 | 2 | `p = clamp(params)` |

### basis_factor: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0010 | 0.0011 | 16 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0009 | 0.0009 | 14 |
| model_a/simulate.py:31 (chol_factor) | 0.0003 | 0.0031 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0002 | 0.0002 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/array_methods.py:795 (_operator_truediv) | 0.0001 | 0.0001 | 2 |

Identical workload summaries across the three passes: True.

### basis_factor: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/simulate.py:34 | 0.0028 | 2 | `K = jnp.exp(-0.5 * d * d / (sig * sig)) + 1e-12 * jnp.eye(N)` |
| model_a/simulate.py:33 | 0.0011 | 2 | `d = IDX[:, None] - IDX[None, :]` |
| model_a/simulate.py:35 | 0.0002 | 2 | `return jnp.linalg.cholesky(K)` |
