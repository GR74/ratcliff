# H100 speedup screening results

All comparisons use this run's GPU, software and synthetic observed data.
Final pilot budget: 9000 trials/condition, 40 iterations.
Initial compilation/warm-up is reported separately from timed fitting.

| Model | Variant | Start seed | Fit seconds | Mean active error | Independent G2 | Converged |
|---|---|---:|---:|---:|---:|---|
| A | legacy | 0 | 9.71 | 4.71% | 91.766 | False |
| A | early_stop | 0 | 9.61 | 4.88% | 79.129 | False |
| A | combined | 0 | 11.63 | 4.15% | 74.458 | False |
| B | legacy | 0 | 307.55 | 5.85% | 165.224 | False |
| B | early_stop | 0 | 77.94 | 6.13% | 187.709 | False |
| B | combined | 0 | 72.08 | 5.23% | 105.050 | False |
| A | early_stop | 1 | 10.45 | 3.41% | 93.691 | False |
| A | combined | 1 | 11.21 | 4.54% | 104.240 | False |
| A | legacy | 1 | 9.90 | 4.56% | 98.826 | False |
| B | early_stop | 1 | 86.86 | 3.99% | 81.078 | False |
| B | combined | 1 | 102.29 | 4.44% | 79.650 | False |
| B | legacy | 1 | 335.60 | 3.95% | 68.323 | False |
| A | combined | 2 | 11.91 | 2.83% | 75.229 | False |
| A | legacy | 2 | 11.26 | 2.04% | 83.530 | False |
| A | early_stop | 2 | 11.91 | 2.60% | 81.825 | False |
| B | combined | 2 | 80.87 | 3.58% | 68.974 | False |
| B | legacy | 2 | 392.47 | 3.73% | 56.895 | False |
| B | early_stop | 2 | 85.30 | 4.04% | 59.069 | False |

| Comparison | Median fit speedup | Bootstrap 95% interval | Pilot finding |
|---|---:|---|---|
| a:legacy->combined | 0.85x | 0.83-0.95x | not established in this pilot |
| a:legacy->early_stop | 0.95x | 0.95-1.01x | not established in this pilot |
| a:early_stop->combined | 0.90x | 0.83-1.00x | not established in this pilot |
| b:legacy->combined | 4.15x | 3.28-4.85x | not established in this pilot |
| b:legacy->early_stop | 3.93x | 3.86-4.60x | not established in this pilot |
| b:early_stop->combined | 1.05x | 0.85-1.08x | not established in this pilot |

The comparison separates legacy code from the paired indexed-noise control.
Distribution intervals and sparse-category limitations are in summary.json.
A screening pass is not proof of equivalence across all datasets or parameters.
Counts, seeds, GPU/driver, package versions, source commit, memory and warm-up
measurements are retained in results.json. Interrupted cases are recorded too.
