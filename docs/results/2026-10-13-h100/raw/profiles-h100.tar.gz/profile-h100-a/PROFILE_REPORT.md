# Python profiling diagnostics

- cProfile and line_profiler measure the Python host; they do not time individual XLA/GPU kernels.
- Every workload waits for JAX results. A wait can absorb earlier asynchronous work, so its line is not a kernel location.
- JIT bodies execute as compiled code after tracing; zero line hits there do not mean zero compute cost.
- Unwrapping JIT functions only registers source mappings; this script never invokes their eager versions.
- Compilation/first calls are separate from steady-state passes. New shapes or basis operations during a fit can still compile.
- Instrumented durations include profiler overhead and are not speedup evidence; use benchmark_speedups.py for comparisons.
- Basis cold means an empty Python K-L basis cache, not an empty XLA or operating-system cache.
- Cumulative function times overlap and must not be added together.
- Fits use synthetic data, fixed seeds and a small iteration budget; these are bottleneck diagnostics, not convergence/recovery tests.

## A / legacy

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 0.0263 | 0.0332 | 0.0424 |
| objective | 2 | 0.2046 | 0.3166 | 0.4127 |
| basis_factor | 2 | 0.0044 | 0.0042 | 0.0059 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0131 | 0.0135 | 186 |
| scripts/profile_speedups.py:205 (simulate_arrays) | 0.0018 | 0.0328 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0015 | 0.0016 | 16 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0009 | 0.0009 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0009 | 0.0193 | 194 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| scripts/profile_speedups.py:136 | 0.0425 | 1 | `row["line_profiler_seconds"], row["line_profiler_result"] = timed(batch)` |
| scripts/profile_speedups.py:51 | 0.0424 | 1 | `value = call()` |
| scripts/profile_speedups.py:227 | 0.0422 | 2 | `rt, cat = self.simulate_arrays()` |
| scripts/profile_speedups.py:214 | 0.0173 | 8 | `values = (key, p[0], p[1], p[bi], p[3], p[4], p[5], p[di], nsim, self.chunk)` |
| scripts/profile_speedups.py:207 | 0.0147 | 2 | `p, sim = self.clamp(self.params), self.simulator` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0625 | 0.0643 | 676 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0441 | 0.0490 | 552 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0104 | 0.2125 | 1100 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0104 | 0.2418 | 2336 |
| .venv/lib/python3.12/site-packages/jax/_src/util.py:270 (wrapper) | 0.0092 | 0.0154 | 5870 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/objective.py:121 | 0.3678 | 4 | `g2_per_cond = g2_vmap(` |
| model_a/objective.py:70 | 0.3639 | 2 | `contribs = jnp.array([per_cat(i) for i in range(MC)])` |
| model_a/objective.py:87 | 0.0138 | 2 | `p = clamp(params)` |
| model_a/objective.py:91 | 0.0082 | 2 | `boundaries = jnp.stack([p[bi] for (_, bi) in COND_MAP])  # (4,)` |
| model_a/objective.py:94 | 0.0077 | 2 | `cond_keys = jnp.stack([prng.split_for_condition(key, ci) for ci in range(4)])` |

### basis_factor: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0010 | 0.0010 | 14 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0009 | 0.0010 | 16 |
| model_a/simulate.py:31 (chol_factor) | 0.0003 | 0.0031 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0002 | 0.0002 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/array_methods.py:667 (_operator_eq) | 0.0001 | 0.0001 | 2 |

Identical workload summaries across the three passes: True.

### basis_factor: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/simulate.py:34 | 0.0029 | 2 | `K = jnp.exp(-0.5 * d * d / (sig * sig)) + 1e-12 * jnp.eye(N)` |
| model_a/simulate.py:33 | 0.0011 | 2 | `d = IDX[:, None] - IDX[None, :]` |
| model_a/simulate.py:35 | 0.0002 | 2 | `return jnp.linalg.cholesky(K)` |

## A / combined

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 0.0285 | 0.0354 | 0.0430 |
| objective | 2 | 0.2011 | 0.3119 | 0.4126 |
| basis_factor | 2 | 0.0036 | 0.0039 | 0.0050 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0121 | 0.0125 | 186 |
| model_a/simulate.py:165 (simulate_blocked) | 0.0051 | 0.0051 | 8 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0014 | 0.0015 | 16 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0009 | 0.0185 | 194 |
| ~:0 (<built-in method builtins.isinstance>) | 0.0008 | 0.0009 | 3988 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/simulate.py:169 | 0.0050 | 16 | `rt, cat, _work = simulate_blocked_with_work(` |
| model_a/simulate.py:173 | 0.0000 | 8 | `return rt, cat` |
| model_a/simulate.py:170 | 0.0000 | 8 | `key, ter, st, cr, crsd, si, sig, av, nsim, chunk_size,` |
| model_a/simulate.py:171 | 0.0000 | 8 | `time_block_size, stop_early, compact,` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0618 | 0.0639 | 728 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0377 | 0.0426 | 550 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0106 | 0.2008 | 1098 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0105 | 0.2347 | 2384 |
| .venv/lib/python3.12/site-packages/jax/_src/util.py:270 (wrapper) | 0.0092 | 0.0154 | 5894 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/objective.py:121 | 0.3668 | 4 | `g2_per_cond = g2_vmap(` |
| model_a/objective.py:70 | 0.3623 | 2 | `contribs = jnp.array([per_cat(i) for i in range(MC)])` |
| model_a/objective.py:87 | 0.0129 | 2 | `p = clamp(params)` |
| model_a/objective.py:101 | 0.0096 | 8 | `cond_keys[ci], ter, st, boundaries[ci], sa, si, sig, drifts[ci],` |
| model_a/objective.py:94 | 0.0065 | 2 | `cond_keys = jnp.stack([prng.split_for_condition(key, ci) for ci in range(4)])` |

### basis_factor: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0009 | 0.0009 | 16 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0008 | 0.0008 | 14 |
| model_a/simulate.py:31 (chol_factor) | 0.0003 | 0.0029 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0001 | 0.0001 | 2 |
| ~:0 (<built-in method builtins.isinstance>) | 0.0001 | 0.0001 | 352 |

Identical workload summaries across the three passes: True.

### basis_factor: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_a/simulate.py:34 | 0.0026 | 2 | `K = jnp.exp(-0.5 * d * d / (sig * sig)) + 1e-12 * jnp.eye(N)` |
| model_a/simulate.py:33 | 0.0010 | 2 | `d = IDX[:, None] - IDX[None, :]` |
| model_a/simulate.py:35 | 0.0001 | 2 | `return jnp.linalg.cholesky(K)` |
