# Python profiling diagnostics

- cProfile and line_profiler measure the Python host; they do not time individual XLA/GPU kernels.
- Every workload waits for JAX results. A wait can absorb earlier asynchronous work, so its line is not a kernel location.
- JIT bodies execute as compiled code after tracing; zero line hits there do not mean zero compute cost.
- Unwrapping JIT functions only registers source mappings; this script never invokes their eager versions.
- Compilation/first calls are separate from steady-state passes. New shapes or basis operations during a fit can still compile.
- Instrumented durations include profiler overhead and are not speedup evidence; use benchmark_speedups.py for comparisons.
- Basis cold means an empty Python K-L basis cache, not an empty XLA or operating-system cache.
- Cumulative function times overlap and must not be added together.
- Fits use synthetic data, fixed seeds and a small iteration budget; these are bottleneck diagnostics, not convergence/recovery tests.

## B / legacy

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 0.1217 | 0.1519 | 0.1427 |
| objective | 2 | 0.4801 | 0.5982 | 0.8047 |
| basis_cold | 1 | 0.9140 | 0.8880 | 0.8898 |
| basis_cache_hit | 2 | 0.0027 | 0.0013 | 0.0018 |
| fit | 1 | 11.1069 | 12.1065 | 13.8134 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2479 (block_until_ready) | 0.0514 | 0.0514 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0405 | 0.0406 | 8 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0188 | 0.0198 | 128 |
| model_b/simulate.py:273 (simulate_b) | 0.0023 | 0.0024 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0021 | 0.0329 | 132 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/objective.py:49 | 0.0062 | 2 | `jnp.array([ter, st, cr, crsd, sis, sig, sv]),` |
| model_b/objective.py:40 | 0.0019 | 2 | `ter = jnp.maximum(params[0], 175.0)` |
| model_b/objective.py:43 | 0.0017 | 2 | `crsd = jnp.clip(params[3], 0.01, cr / 2.0)` |
| model_b/objective.py:41 | 0.0016 | 2 | `st = jnp.clip(params[1], 10.0, ter * 1.5)` |
| model_b/simulate.py:302 | 0.0015 | 8 | `return _simulate_b_kl_inner(` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.1769 | 0.1797 | 1046 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0692 | 0.0783 | 916 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0185 | 0.4390 | 1828 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0180 | 0.4790 | 3794 |
| .venv/lib/python3.12/site-packages/jax/_src/util.py:270 (wrapper) | 0.0157 | 0.0255 | 9470 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/objective.py:153 | 0.7661 | 2 | `g2_per_cond = g2_vmap(rts, cats, data["prop"], data["count"], data["quant"])` |
| model_b/objective.py:88 | 0.7629 | 2 | `return jnp.array([per_cat(i) for i in range(MC)]).sum()` |
| model_b/objective.py:106 | 0.0117 | 2 | `p = clamp_b(params)` |
| model_b/objective.py:112 | 0.0070 | 6 | `jnp.array([p[d1], p[d2], p[d3]]) for (d1, d2, d3) in COND_MAP_B` |
| model_b/objective.py:144 | 0.0062 | 4 | `rts, cats = sim_vmap(` |

### basis_cold: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/grf_kl.py:77 (_calc_kl_basis_impl) | 0.7722 | 0.8808 | 1 |
| ~:0 (<method 'astype' of 'numpy.ndarray' objects>) | 0.0648 | 0.0648 | 12 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0330 | 0.0331 | 46 |
| model_b/grf_kl.py:26 (_cached_calc_kl_basis) | 0.0025 | 0.8833 | 1 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0022 | 0.0022 | 1 |

Identical workload summaries across the three passes: True.

### basis_cold: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.8860 | 2 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:31 | 0.8860 | 1 | `result = _calc_kl_basis_impl(sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:121 | 0.3101 | 1 | `re = (np.cos(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:122 | 0.3011 | 1 | `im = (np.sin(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:128 | 0.0892 | 1 | `V[:, 0 : 2 * K : 2] = re.T        # even columns = real parts` |

### basis_cache_hit: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0004 | 0.0004 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0004 | 0.0004 | 2 |
| scripts/profile_speedups.py:188 (build_basis) | 0.0000 | 0.0012 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/indexing.py:359 (to_static_slice) | 0.0000 | 0.0001 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/indexing.py:118 (_parse_indices) | 0.0000 | 0.0000 | 2 |

Identical workload summaries across the three passes: True.

### basis_cache_hit: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.0000 | 4 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:72 | 0.0000 | 2 | `sig_key = round(float(sig), 6)` |
| model_b/grf_kl.py:28 | 0.0000 | 2 | `cached = _basis_cache.get(cache_key)` |
| model_b/grf_kl.py:27 | 0.0000 | 2 | `cache_key = (sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:29 | 0.0000 | 2 | `if cached is not None:` |

### fit: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/grf_kl.py:77 (_calc_kl_basis_impl) | 4.9539 | 5.8633 | 8 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 2.1225 | 2.1544 | 11357 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.7762 | 0.8736 | 9986 |
| ~:0 (<method 'astype' of 'numpy.ndarray' objects>) | 0.4042 | 0.4042 | 96 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.2036 | 4.6594 | 19906 |

Identical workload summaries across the three passes: True.

### fit: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/fit.py:55 | 13.8128 | 2 | `res = minimize_staged(` |
| shared/staged_fit.py:66 | 13.8127 | 2 | `result = minimize(` |
| model_b/objective.py:153 | 7.5274 | 21 | `g2_per_cond = g2_vmap(rts, cats, data["prop"], data["count"], data["quant"])` |
| model_b/objective.py:88 | 7.4920 | 21 | `return jnp.array([per_cat(i) for i in range(MC)]).sum()` |
| model_b/objective.py:144 | 5.9574 | 42 | `rts, cats = sim_vmap(` |

## B / combined

Backend: gpu; device: NVIDIA H100 80GB HBM3. Status: completed.

| Workload | Calls per pass | No profiler (s) | cProfile (s) | line_profiler (s) |
|---|---:|---:|---:|---:|
| simulation | 2 | 0.0506 | 0.0597 | 0.0725 |
| objective | 2 | 0.3411 | 0.5402 | 0.7374 |
| basis_cold | 1 | 0.8367 | 0.8328 | 0.8476 |
| basis_cache_hit | 2 | 0.0024 | 0.0013 | 0.0016 |
| fit | 1 | 11.1386 | 14.9848 | 18.4114 |

### simulation: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0133 | 0.0138 | 232 |
| model_b/simulate.py:351 (simulate_b_blocked_with_work) | 0.0108 | 0.0379 | 4 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/ufunc_api.py:175 (__call__) | 0.0075 | 0.0081 | 118 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/array_methods.py:795 (_operator_truediv) | 0.0025 | 0.0025 | 50 |
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0015 | 0.0015 | 8 |

Identical workload summaries across the three passes: True.

### simulation: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/simulate.py:382 | 0.0429 | 8 | `rt, cat, _work = simulate_b_blocked_with_work(` |
| model_b/simulate.py:373 | 0.0187 | 4 | `key, ter, st, cr, crsd, drift.reshape(-1), zone_array(si).reshape(-1),` |
| model_b/simulate.py:372 | 0.0107 | 8 | `return _simulate_b_blocked_core(` |
| model_b/simulate.py:362 | 0.0091 | 4 | `v1, v2, v3 = drift_bumps(sis=sis)` |
| model_b/simulate.py:50 | 0.0079 | 4 | `return bump(UJ1), bump(UJ2), bump(UJ3)` |

### objective: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.1006 | 0.1038 | 1174 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 0.0697 | 0.0778 | 914 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.0180 | 0.3957 | 3918 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.0177 | 0.3466 | 1826 |
| .venv/lib/python3.12/site-packages/jax/_src/util.py:270 (wrapper) | 0.0152 | 0.0250 | 9606 |

Identical workload summaries across the three passes: True.

### objective: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/objective.py:153 | 0.6540 | 2 | `g2_per_cond = g2_vmap(rts, cats, data["prop"], data["count"], data["quant"])` |
| model_b/objective.py:88 | 0.6499 | 2 | `return jnp.array([per_cat(i) for i in range(MC)]).sum()` |
| model_b/objective.py:131 | 0.0453 | 10 | `outputs = [sim_b.simulate_b_blocked(` |
| model_b/simulate.py:382 | 0.0452 | 8 | `rt, cat, _work = simulate_b_blocked_with_work(` |
| model_b/simulate.py:373 | 0.0196 | 4 | `key, ter, st, cr, crsd, drift.reshape(-1), zone_array(si).reshape(-1),` |

### basis_cold: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/grf_kl.py:77 (_calc_kl_basis_impl) | 0.7088 | 0.8258 | 1 |
| ~:0 (<method 'astype' of 'numpy.ndarray' objects>) | 0.0598 | 0.0598 | 12 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0467 | 0.0470 | 46 |
| .venv/lib/python3.12/site-packages/jax/_src/api.py:2490 (try_to_block) | 0.0027 | 0.0027 | 1 |
| model_b/grf_kl.py:26 (_cached_calc_kl_basis) | 0.0019 | 0.8278 | 1 |

Identical workload summaries across the three passes: True.

### basis_cold: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.8432 | 2 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:31 | 0.8431 | 1 | `result = _calc_kl_basis_impl(sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:122 | 0.2920 | 1 | `im = (np.sin(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:121 | 0.2877 | 1 | `re = (np.cos(phase) * scale).reshape(K, n * m).astype(np.float32)` |
| model_b/grf_kl.py:128 | 0.0863 | 1 | `V[:, 0 : 2 * K : 2] = re.T        # even columns = real parts` |

### basis_cache_hit: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| .venv/lib/python3.12/site-packages/jax/_src/array.py:615 (_value) | 0.0004 | 0.0004 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 0.0004 | 0.0004 | 4 |
| scripts/profile_speedups.py:188 (build_basis) | 0.0000 | 0.0012 | 2 |
| .venv/lib/python3.12/site-packages/jax/_src/numpy/indexing.py:359 (to_static_slice) | 0.0000 | 0.0001 | 2 |
| ~:0 (<method 'disable' of '_lsprof.Profiler' objects>) | 0.0000 | 0.0000 | 1 |

Identical workload summaries across the three passes: True.

### basis_cache_hit: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/grf_kl.py:73 | 0.0000 | 4 | `return _cached_calc_kl_basis(sig_key, n, m, k_max,` |
| model_b/grf_kl.py:72 | 0.0000 | 2 | `sig_key = round(float(sig), 6)` |
| model_b/grf_kl.py:27 | 0.0000 | 2 | `cache_key = (sig_key, n, m, k_max, variance_threshold, pad_to_k_max)` |
| model_b/grf_kl.py:28 | 0.0000 | 2 | `cached = _basis_cache.get(cache_key)` |
| model_b/grf_kl.py:30 | 0.0000 | 2 | `return cached` |

### fit: highest cProfile self times

| Function | Self seconds | Cumulative seconds | Calls |
|---|---:|---:|---:|
| model_b/grf_kl.py:77 (_calc_kl_basis_impl) | 2.8468 | 3.3287 | 5 |
| .venv/lib/python3.12/site-packages/jax/_src/dispatch.py:81 (apply_primitive) | 2.2554 | 2.3280 | 26681 |
| .venv/lib/python3.12/site-packages/jax/_src/pjit.py:1207 (_pjit_call_impl) | 1.4026 | 1.5865 | 20565 |
| .venv/lib/python3.12/site-packages/jax/_src/core.py:660 (bind) | 0.4109 | 8.7582 | 88421 |
| .venv/lib/python3.12/site-packages/jax/_src/interpreters/batching.py:255 (process_primitive) | 0.3995 | 7.4452 | 41085 |

Identical workload summaries across the three passes: True.

### fit: highest recorded Python line times

| Source | Seconds | Hits | Code |
|---|---:|---:|---|
| model_b/fit.py:55 | 18.4109 | 2 | `res = minimize_staged(` |
| shared/staged_fit.py:66 | 18.4106 | 6 | `result = minimize(` |
| model_b/objective.py:153 | 13.4607 | 45 | `g2_per_cond = g2_vmap(rts, cats, data["prop"], data["count"], data["quant"])` |
| model_b/objective.py:88 | 13.3886 | 45 | `return jnp.array([per_cat(i) for i in range(MC)]).sum()` |
| model_b/objective.py:131 | 4.1870 | 225 | `outputs = [sim_b.simulate_b_blocked(` |
