import hashlib
import json
from pathlib import Path
from statistics import median
import tarfile

import numpy as np

repo = Path('C:/Personal_Coding/ratcliff-1')
base = Path('D:/ratcliff-3060')
study = base / 'results/study-512-six-hour'
report = repo / 'docs/results/2026-10-13-rtx3060'
rows = json.loads((study / 'results.json').read_text())
planned = json.loads((study / 'planned-jobs.json').read_text())
assert len(rows) == len(planned) == 25
assert all(r['metadata']['backend'] == 'gpu' for r in rows)
snapshot_hash = hashlib.sha256((study / 'validation-driver-snapshot.py').read_bytes()).hexdigest()
assert snapshot_hash == hashlib.sha256((repo / 'scripts/validate_early_stopping.py').read_bytes()).hexdigest()
assert all(r['metadata']['validation_driver_sha256'] == snapshot_hash for r in rows)
digest = hashlib.sha256()
for name in rows[0]['metadata']['hashed_files']:
    digest.update(name.encode())
    digest.update((repo / name).read_bytes())
assert all(r['metadata']['implementation_sha256'] == digest.hexdigest() for r in rows)
fits = [r for r in rows if r['action'] == 'fit']
scores = [r for r in rows if r['action'] == 'score']
assert len(fits) == len(scores) == 8
for f in fits:
    s = next(r for r in scores if (r['scenario'], r['start_seed'], r['variant']) ==
             (f['scenario'], f['start_seed'], f['variant']))
    assert s['status'] == 'completed' and s['score_seeds'] == [999, 5001, 5002]
    assert s['score_nsim'] == 9000 and f['settings']['nsim'] == 512
    assert f['params'] == s['final_params'] == s['scored_checkpoints'][-1]['params']
    truth = median(s['truth_g2_by_seed'])
    for checkpoint in s['scored_checkpoints']:
        assert len(checkpoint['independent_g2_by_seed']) == 3
        assert checkpoint['independent_g2_median'] == median(checkpoint['independent_g2_by_seed'])
        expected = (checkpoint['mean_active_effective_parameter_error'] <= .05 and
                    checkpoint['independent_g2_median'] <= truth + .1 * max(abs(truth), 1.) + 1.)
        assert checkpoint['target_pass'] == expected
    assert not s['target_reached']
paired_trials = 0
for scenario in ('baseline', 'lower_boundary', 'higher_boundary'):
    for seed in range(3):
        with np.load(study / f'samples-{scenario}-blocked_full-{seed}.npz') as a, \
                np.load(study / f'samples-{scenario}-early_stop-{seed}.npz') as b:
            assert a['rt'].shape == b['rt'].shape == (2, 512)
            assert np.array_equal(a['rt'], b['rt']) and np.array_equal(a['cat'], b['cat'])
            paired_trials += a['rt'].size
assert paired_trials == 9216
manifest = json.loads((report / 'raw/manifest.json').read_text())
for record in manifest:
    path = report / 'raw' / record['archive']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']
    with tarfile.open(path, 'r:gz') as archive:
        assert len(archive.getmembers()) == len(record['files'])
        for item in record['files']:
            payload = archive.extractfile(item['path']).read()
            assert len(payload) == item['bytes']
            assert hashlib.sha256(payload).hexdigest() == item['sha256']
summary = dict(planned_and_recorded_jobs=25, gpu_worker_records=25, scored_fits=8,
    quality_target_hits=0, paired_exact_trials=paired_trials,
    original_time_capped_fits=sum(f['status'] == 'fit_time_limit' for f in fits),
    validation_driver_sha256=snapshot_hash, implementation_sha256=digest.hexdigest(),
    archive_count=len(manifest), archive_total_bytes=sum(r['bytes'] for r in manifest),
    archive_and_file_hashes_verified=True, final_score_vectors_match_returned_fits=True)
(report / 'audit.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
