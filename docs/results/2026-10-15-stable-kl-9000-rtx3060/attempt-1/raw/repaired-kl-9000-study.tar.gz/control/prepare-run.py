import hashlib
import json
from pathlib import Path
import shutil
import tarfile

control = Path('/mnt/c/Personal_Coding/ratcliff-1/.benchmark-results/stable-kl-9000-3060/control')
active = json.loads((control / 'active-study.json').read_text())
base = Path(active['linux_base'])
if base.exists():
    raise ValueError('Choose a fresh native Linux experiment directory')
checkout = base / 'checkout'
checkout.mkdir(parents=True)
archive = control / 'source.tar'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == active['source_tar_sha256']
with tarfile.open(archive) as handle:
    for member in handle.getmembers():
        target = (checkout / member.name).resolve()
        assert target.is_relative_to(checkout.resolve())
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        elif member.isfile():
            target.parent.mkdir(parents=True, exist_ok=True)
            with handle.extractfile(member) as source, target.open('wb') as destination:
                shutil.copyfileobj(source, destination)
        else:
            raise ValueError('Unexpected archive entry')
files = {p.relative_to(checkout).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in checkout.rglob('*') if p.is_file()}
manifest = checkout / 'source-manifest.json'
manifest.write_text(json.dumps(files, indent=2))
(checkout / 'benchmark-source.json').write_text(json.dumps(dict(
    commit=active['source_commit'], source_tar_sha256=active['source_tar_sha256'],
    manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(), file_count=len(files)), indent=2))
shutil.copytree(control / 'observations', base / 'observations')
record = json.loads((base / 'observations/data-baseline-0-legacy.json').read_text())
assert hashlib.sha256((base / 'observations/data-baseline.npz').read_bytes()).hexdigest() == record['data_sha256']
shutil.copyfile(control / 'launch.py', base / 'launch.py')
print('Prepared immutable source snapshot and fingerprint-verified observations on native Linux storage.')
