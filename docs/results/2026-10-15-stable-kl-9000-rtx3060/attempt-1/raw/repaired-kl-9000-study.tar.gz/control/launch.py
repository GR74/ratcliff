import os
from pathlib import Path
import resource

base = Path('/home/anik278/ratcliff-kl-9000-20261015')
venv = Path('/home/anik278/.venvs/ratcliff-kl-3060')
site = venv / 'lib/python3.12/site-packages'
env = os.environ.copy()
env.update(JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
           XLA_PYTHON_CLIENT_PREALLOCATE='false', XLA_PYTHON_CLIENT_MEM_FRACTION='.5',
           CUDA_VISIBLE_DEVICES='0', PYTHONUNBUFFERED='1')
env['LD_LIBRARY_PATH'] = ':'.join(str(p) for p in (site / 'nvidia').glob('*/lib')) + ':/usr/lib/wsl/lib'
env['PATH'] = ':'.join([str(venv / 'bin'),
                        *(str(p) for p in (site / 'nvidia').glob('*/bin')), env.get('PATH', '')])
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
os.chdir(base / 'checkout')
python = str(venv / 'bin/python')
command = [python, '-u', str(base / 'checkout/scripts/validate_early_stopping.py'),
    '--output', str(base / 'study'), '--data-source', str(base / 'observations'),
    '--scenarios', 'baseline', '--start-seeds', '1', '--starts', '1',
    '--nsim', '9000', '--data-nsim', '9000', '--score-nsim', '9000',
    '--stable-kl-noise', '--chunk', '8', '--sim-seeds', '1', '--repeats', '1',
    '--maxiter', '1000', '--fit-seconds-limit', '8100', '--basis-cache-size', '2',
    '--checkpoint-every', '25', '--max-score-checkpoints', '2', '--error-limit', '.05',
    '--budget-seconds', '21600', '--score-reserve-seconds', '1800', '--reserve-seconds', '180',
    '--deadline-utc', '2026-10-15T23:24:24Z']
os.execve(python, command, env)
