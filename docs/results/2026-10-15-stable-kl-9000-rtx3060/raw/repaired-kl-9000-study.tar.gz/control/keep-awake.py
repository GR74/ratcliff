"""Hold a reversible idle-sleep request only while this guarded run is active."""
import ctypes
from datetime import datetime, timezone
import json
from pathlib import Path
import time

control = Path(__file__).resolve().parent
deadline = datetime.fromisoformat(json.loads((control / 'active-study.json').read_text())['deadline_utc'].replace('Z', '+00:00'))
kernel = ctypes.windll.kernel32
success = bool(kernel.SetThreadExecutionState(0x80000001))
state_path = control / 'keep-awake-state.json'
state_path.write_text(json.dumps(dict(status='holding' if success else 'request_failed', system_idle_sleep_request=success)))
try:
    while datetime.now(timezone.utc) < deadline:
        state = json.loads((control / 'guard-state.json').read_text())
        if state.get('status') in ('benchmark_processes_exited', 'deadline_enforced'):
            break
        time.sleep(10)
finally:
    kernel.SetThreadExecutionState(0x80000000)
    state_path.write_text(json.dumps(dict(status='released', system_idle_sleep_request=False,
                                         ended_utc=datetime.now(timezone.utc).isoformat())))
